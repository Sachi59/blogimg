<?php 
//#####################################################
// CARLOS SANTOS DE AZEVEDO
// Software: Imagex - Website Image Upload & Managment 
// Website Images Managment without database
// CopyRight: Litos Media - Carlos Santos de Azevedo
// Contact: info@litos.top
// 10-2017
//#####################################################
$LOGIN_ACTIVE='##LOGIN_ACTIVE##'; //1 for active and 0 to deactivate login.
$ImageX_PW='##YOUR_PASSWORD##';
$USER_TYPED_TOP_FOLDER_PATH='##TOP_FOLDER_PATH##';
?>